# CivicConnect — Darbhanga Civic Issue Reporting Platform

A hackathon prototype for reporting and tracking civic issues in Darbhanga, Bihar.
Frontend-only: React + Vite + Tailwind CSS, with mock data persisted in the browser's `localStorage`.

## Run locally

```bash
npm install
npm run dev
```

Then open the printed local URL (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: CivicConnect prototype"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

(Create the empty repo on GitHub first — no README/license/gitignore selected there, since this folder already has them.)

## Deploy (optional)

Any static host that runs a Vite build works, e.g. **Vercel** or **Netlify**:
- Build command: `npm run build`
- Output directory: `dist`

## Notes

- No backend, database, or authentication — everything runs in the browser.
- Complaint data is stored in `localStorage` under the key `cc_complaints`, seeded with 12 mock complaints on first load.
- Support contact numbers live in one place: `CONFIG` at the top of `src/App.jsx`.
