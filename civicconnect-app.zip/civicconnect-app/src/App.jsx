import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  MapPin, Phone, MessageCircle, Menu, X, Camera, Upload, CheckCircle2, Circle,
  Clock, AlertTriangle, TrendingUp, Filter, Search, ChevronRight, ChevronDown,
  ChevronLeft, Home as HomeIcon, ClipboardList, LayoutDashboard, Info, Image as ImageIcon,
  Building2, ShieldCheck, BarChart3, ArrowRight, ArrowLeft, Loader2, Send,
  Trash2, Droplets, Waves, Signpost, Trees, Construction, Zap, Lightbulb,
  HelpCircle, Route, Calendar, User, Sparkles, RefreshCw, Eye, PlusCircle,
  CheckCircle, XCircle, FileText, Users, Award
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";

/* ============================== CONFIG ============================== */

const CONFIG = {
  callNumber: "7488699669",
  whatsappNumber: "8406940095",
  whatsappMessage: "Hello CivicConnect, I want to report a civic issue in Darbhanga.",
};
const TEL_LINK = `tel:${CONFIG.callNumber}`;
const WA_LINK = `https://wa.me/91${CONFIG.whatsappNumber}?text=${encodeURIComponent(CONFIG.whatsappMessage)}`;

const CATEGORIES = [
  { id: "road", label: "Road / Pothole", icon: Route, desc: "Potholes, cracked roads and damaged pavements." },
  { id: "streetlight", label: "Streetlight", icon: Lightbulb, desc: "Non-functional or damaged streetlights." },
  { id: "garbage", label: "Garbage", icon: Trash2, desc: "Uncollected waste and overflowing bins." },
  { id: "water", label: "Water Leakage", icon: Droplets, desc: "Pipeline leaks and drinking water wastage." },
  { id: "drainage", label: "Drainage / Sewer", icon: Waves, desc: "Blocked drains and sewage overflow." },
  { id: "traffic", label: "Traffic Signal", icon: Signpost, desc: "Faulty, missing or damaged traffic signals." },
  { id: "park", label: "Public Park", icon: Trees, desc: "Damaged or unmaintained park facilities." },
  { id: "infrastructure", label: "Public Infrastructure", icon: Construction, desc: "Damaged public property and structures." },
  { id: "electrical", label: "Electrical Issue", icon: Zap, desc: "Exposed wiring and electrical hazards." },
  { id: "other", label: "Other Civic Issue", icon: HelpCircle, desc: "Any other civic concern not listed above." },
];
const catById = (id) => CATEGORIES.find((c) => c.id === id) || CATEGORIES[CATEGORIES.length - 1];

const DEPARTMENTS = [
  "Darbhanga Municipal Corporation",
  "Road & Infrastructure Department",
  "Water Supply Department",
  "Sanitation Department",
  "Electrical Department",
  "Drainage Department",
  "Public Works Department",
];

const AREAS = ["Laheriasarai", "Tower Chowk", "Darbhanga Tower", "Donar", "Benta", "Kadirabad", "University Area", "Station Road"];

const PRIORITIES = [
  { id: "Low", desc: "Minor inconvenience", classes: "bg-slate-100 text-slate-700 border-slate-300", dot: "bg-slate-400" },
  { id: "Medium", desc: "Needs attention", classes: "bg-amber-50 text-amber-700 border-amber-300", dot: "bg-amber-500" },
  { id: "High", desc: "Significant public impact", classes: "bg-orange-50 text-orange-700 border-orange-300", dot: "bg-orange-500" },
  { id: "Critical", desc: "Immediate attention required", classes: "bg-red-50 text-red-700 border-red-300", dot: "bg-red-600" },
];
const prioById = (id) => PRIORITIES.find((p) => p.id === id) || PRIORITIES[0];

const STATUS_FLOW = ["Reported", "Verified", "Assigned", "In Progress", "Resolved", "Closed"];
const STATUS_STYLE = {
  "Reported": { classes: "bg-slate-100 text-slate-700 border-slate-300" },
  "Verified": { classes: "bg-sky-50 text-sky-700 border-sky-300" },
  "Assigned": { classes: "bg-indigo-50 text-indigo-700 border-indigo-300" },
  "In Progress": { classes: "bg-amber-50 text-amber-700 border-amber-300" },
  "Resolved": { classes: "bg-emerald-50 text-emerald-700 border-emerald-300" },
  "Closed": { classes: "bg-gray-200 text-gray-700 border-gray-400" },
};
const STATUS_NOTES = {
  "Reported": "Complaint submitted by citizen.",
  "Verified": "Issue verified by authority.",
  "Assigned": "Complaint assigned to department.",
  "In Progress": "Field team has started work on the issue.",
  "Resolved": "Issue resolved by department. Proof attached.",
  "Closed": "Complaint closed after citizen confirmation.",
};

/* ============================== HELPERS ============================== */

function pad(n) { return n.toString().padStart(2, "0"); }

function fmtDateTime(d) {
  const day = pad(d.getDate());
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  let h = d.getHours(); const m = pad(d.getMinutes());
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12; if (h === 0) h = 12;
  return `${day} ${months[d.getMonth()]} ${d.getFullYear()}, ${h}:${m} ${ampm}`;
}

function buildTimeline(finalStatus, baseDate) {
  const idx = STATUS_FLOW.indexOf(finalStatus);
  const timeline = [];
  for (let i = 0; i <= idx; i++) {
    const d = new Date(baseDate.getTime() + i * (14 + Math.random() * 20) * 3600 * 1000);
    timeline.push({ status: STATUS_FLOW[i], date: fmtDateTime(d), note: STATUS_NOTES[STATUS_FLOW[i]] });
  }
  return timeline;
}

function randOf(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

const ISSUE_TEMPLATES = [
  { cat: "road", title: "Large pothole near main road", desc: "A large pothole has formed causing difficulty for two-wheelers and creating a potential accident risk." },
  { cat: "streetlight", title: "Streetlight not working for a week", desc: "The streetlight on this stretch has not been working for over a week, making the area unsafe at night." },
  { cat: "garbage", title: "Garbage accumulation on roadside", desc: "Waste has not been collected for several days and is spilling onto the road, causing a health hazard." },
  { cat: "water", title: "Water pipeline leakage", desc: "A public water pipeline is leaking continuously, wasting water and damaging the road surface." },
  { cat: "drainage", title: "Blocked drain causing waterlogging", desc: "The drain is blocked with debris, leading to waterlogging on the street after rain." },
  { cat: "traffic", title: "Traffic signal malfunctioning", desc: "The traffic signal at this junction is not functioning properly, causing confusion for commuters." },
  { cat: "park", title: "Damaged park bench and fencing", desc: "Benches and boundary fencing in the park have broken and need repair for public safety." },
  { cat: "infrastructure", title: "Damaged footpath tiles", desc: "Several footpath tiles are broken, creating a tripping hazard for pedestrians." },
  { cat: "electrical", title: "Exposed electrical wiring near pole", desc: "Loose wiring is hanging from a nearby pole, posing a serious safety risk to passersby." },
  { cat: "other", title: "Encroachment blocking public pathway", desc: "Illegal encroachment is blocking a section of the public footpath, forcing pedestrians onto the road." },
];

function generateSeedComplaints() {
  const list = [];
  const statuses = ["Reported", "Verified", "Assigned", "In Progress", "In Progress", "Resolved", "Resolved", "Closed", "Assigned", "In Progress", "Reported", "Resolved"];
  for (let i = 0; i < statuses.length; i++) {
    const tpl = ISSUE_TEMPLATES[i % ISSUE_TEMPLATES.length];
    const priority = randOf(PRIORITIES).id;
    const area = randOf(AREAS);
    const status = statuses[i];
    const idx = STATUS_FLOW.indexOf(status);
    const base = new Date(2026, 7, 5 + i);
    const timeline = buildTimeline(status, base);
    const department = idx >= 2 ? randOf(DEPARTMENTS) : null;
    const resolved = status === "Resolved" || status === "Closed";
    list.push({
      id: `CC-DAR-2026-${1001 + i}`,
      category: tpl.cat,
      title: tpl.title,
      description: tpl.desc,
      area,
      landmark: `${area} Chowk`,
      address: `Near ${area} Chowk, ${area}, Darbhanga, Bihar`,
      pincode: "846001",
      priority,
      status,
      department,
      officer: department ? "Field Officer, " + department.split(" ")[0] : null,
      image: null,
      timeline,
      resolution: resolved ? { note: "The reported issue has been fixed by the concerned department team.", proofImage: null } : null,
      createdAt: timeline[0].date,
    });
  }
  return list;
}

function genComplaintId(existing) {
  const nums = existing.map((c) => parseInt(c.id.split("-").pop(), 10)).filter((n) => !isNaN(n));
  const next = (nums.length ? Math.max(...nums) : 1041) + 1;
  return `CC-DAR-2026-${next}`;
}

/* ============================== SMALL UI PRIMITIVES ============================== */

function PriorityBadge({ priority, size = "sm" }) {
  const p = prioById(priority);
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border font-semibold ${p.classes} ${size === "sm" ? "px-2.5 py-0.5 text-xs" : "px-3 py-1 text-sm"}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${p.dot}`} />
      {priority}
    </span>
  );
}

function StatusBadge({ status, size = "sm" }) {
  const s = STATUS_STYLE[status] || STATUS_STYLE["Reported"];
  return (
    <span className={`inline-flex items-center rounded-full border font-semibold ${s.classes} ${size === "sm" ? "px-2.5 py-0.5 text-xs" : "px-3 py-1 text-sm"}`}>
      {status}
    </span>
  );
}

function CategoryIcon({ id, className }) {
  const c = catById(id);
  const Icon = c.icon;
  return <Icon className={className} />;
}

function TicketStamp({ id, compact }) {
  return (
    <div className={`relative inline-flex items-center gap-2 rounded-lg border-2 border-dashed border-teal-600/50 bg-teal-50/70 ${compact ? "px-3 py-1.5" : "px-4 py-2.5"}`}>
      <span className="absolute -top-2 -right-2 rotate-6 rounded bg-blue-900 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white shadow-sm">Official</span>
      <FileText className={`${compact ? "h-3.5 w-3.5" : "h-4 w-4"} text-blue-900/70 shrink-0`} />
      <span className={`font-mono font-bold tracking-wide text-blue-950 ${compact ? "text-sm" : "text-lg"}`}>{id}</span>
    </div>
  );
}

function PrimaryButton({ children, onClick, className = "", type = "button", full = false, icon: Icon }) {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded-xl bg-teal-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-teal-700 active:scale-[0.98] ${full ? "w-full" : ""} ${className}`}
    >
      {Icon && <Icon className="h-4 w-4" />}
      {children}
    </button>
  );
}
function SecondaryButton({ children, onClick, className = "", full = false, icon: Icon }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded-xl border border-blue-900/20 bg-white px-5 py-3 text-sm font-semibold text-blue-900 shadow-sm transition hover:bg-blue-50 active:scale-[0.98] ${full ? "w-full" : ""} ${className}`}
    >
      {Icon && <Icon className="h-4 w-4" />}
      {children}
    </button>
  );
}

function CallButton({ className = "", label = "Call for Complaint" }) {
  return (
    <a href={TEL_LINK} className={`inline-flex items-center justify-center gap-2 rounded-xl bg-blue-900 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-950 active:scale-[0.98] ${className}`}>
      <Phone className="h-4 w-4" /> {label}
    </a>
  );
}
function WhatsAppButton({ className = "", label = "WhatsApp Complaint" }) {
  return (
    <a href={WA_LINK} target="_blank" rel="noopener noreferrer" className={`inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-700 active:scale-[0.98] ${className}`}>
      <MessageCircle className="h-4 w-4" /> {label}
    </a>
  );
}

function SectionEyebrow({ children }) {
  return <div className="mb-3 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-teal-700">{children}</div>;
}

function EmptyState({ icon: Icon = Search, title, subtitle }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-6 py-14 text-center">
      <Icon className="mb-3 h-9 w-9 text-slate-400" />
      <p className="font-semibold text-slate-700">{title}</p>
      {subtitle && <p className="mt-1 max-w-sm text-sm text-slate-500">{subtitle}</p>}
    </div>
  );
}

/* ============================== TOAST ============================== */

function ToastHost({ toasts }) {
  return (
    <div className="pointer-events-none fixed bottom-4 left-1/2 z-[70] flex w-full max-w-sm -translate-x-1/2 flex-col gap-2 px-4">
      {toasts.map((t) => (
        <div key={t.id} className="pointer-events-auto flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-800 shadow-lg animate-[fadeIn_.2s_ease]">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
          {t.message}
        </div>
      ))}
    </div>
  );
}

/* ============================== TIMELINE ============================== */

function ComplaintTimeline({ timeline, status }) {
  const currentIdx = STATUS_FLOW.indexOf(status);
  return (
    <div>
      {/* Desktop horizontal */}
      <div className="hidden md:block">
        <div className="relative flex items-start justify-between">
          <div className="absolute left-0 right-0 top-4 h-0.5 bg-slate-200" />
          <div
            className="absolute left-0 top-4 h-0.5 bg-teal-600 transition-all"
            style={{ width: `${(Math.max(currentIdx, 0) / (STATUS_FLOW.length - 1)) * 100}%` }}
          />
          {STATUS_FLOW.map((s, i) => {
            const entry = timeline.find((t) => t.status === s);
            const done = i < currentIdx || (i === currentIdx && (status === "Resolved" || status === "Closed"));
            const active = i === currentIdx && !done;
            return (
              <div key={s} className="relative z-10 flex w-full flex-col items-center px-1 text-center">
                <div className={`flex h-8 w-8 items-center justify-center rounded-full border-2 bg-white ${done ? "border-teal-600 text-teal-600" : active ? "border-amber-500 text-amber-500" : "border-slate-300 text-slate-300"}`}>
                  {done ? <CheckCircle2 className="h-5 w-5" /> : active ? <Clock className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
                </div>
                <p className={`mt-2 text-xs font-semibold ${i <= currentIdx ? "text-slate-800" : "text-slate-400"}`}>{s}</p>
                {entry && <p className="mt-0.5 text-[11px] text-slate-400">{entry.date}</p>}
              </div>
            );
          })}
        </div>
      </div>
      {/* Mobile vertical */}
      <div className="space-y-0 md:hidden">
        {STATUS_FLOW.map((s, i) => {
          const entry = timeline.find((t) => t.status === s);
          const done = i < currentIdx || (i === currentIdx && (status === "Resolved" || status === "Closed"));
          const active = i === currentIdx && !done;
          const isLast = i === STATUS_FLOW.length - 1;
          return (
            <div key={s} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 bg-white ${done ? "border-teal-600 text-teal-600" : active ? "border-amber-500 text-amber-500" : "border-slate-300 text-slate-300"}`}>
                  {done ? <CheckCircle2 className="h-5 w-5" /> : active ? <Clock className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
                </div>
                {!isLast && <div className={`w-0.5 flex-1 ${i < currentIdx ? "bg-teal-600" : "bg-slate-200"}`} style={{ minHeight: 28 }} />}
              </div>
              <div className="pb-6">
                <p className={`text-sm font-semibold ${i <= currentIdx ? "text-slate-800" : "text-slate-400"}`}>{s}</p>
                {entry ? (
                  <>
                    <p className="text-xs text-slate-400">{entry.date}</p>
                    <p className="mt-1 text-sm text-slate-600">&ldquo;{entry.note}&rdquo;</p>
                  </>
                ) : (
                  <p className="text-xs text-slate-400">Pending</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================== NAVBAR ============================== */

function NavBar({ page, goto }) {
  const [open, setOpen] = useState(false);
  const links = [
    { id: "home", label: "Home", icon: HomeIcon },
    { id: "report", label: "Report Issue", icon: PlusCircle },
    { id: "track", label: "Track Complaint", icon: Search },
    { id: "dashboard", label: "Authority Dashboard", icon: LayoutDashboard },
    { id: "about", label: "About", icon: Info },
  ];
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <button onClick={() => goto("home")} className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-900">
            <ShieldCheck className="h-5 w-5 text-teal-300" />
          </div>
          <div className="text-left leading-tight">
            <p className="text-base font-extrabold tracking-tight text-blue-950">CivicConnect</p>
            <p className="text-[10px] font-medium uppercase tracking-wider text-slate-400">Darbhanga, Bihar</p>
          </div>
        </button>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <button
              key={l.id}
              onClick={() => goto(l.id)}
              className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${page === l.id ? "bg-blue-50 text-blue-900" : "text-slate-600 hover:bg-slate-50 hover:text-blue-900"}`}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <a href={TEL_LINK} className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 hover:border-blue-900/30 hover:text-blue-900">
            <Phone className="h-3.5 w-3.5" /> {CONFIG.callNumber}
          </a>
          <a href={WA_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 rounded-lg border border-slate-200 p-2 text-emerald-600 hover:border-emerald-300 hover:bg-emerald-50">
            <MessageCircle className="h-4 w-4" />
          </a>
          <PrimaryButton onClick={() => goto("report")} className="px-4 py-2 text-sm">Report an Issue</PrimaryButton>
        </div>

        <button className="lg:hidden" onClick={() => setOpen((v) => !v)} aria-label="Menu">
          {open ? <X className="h-6 w-6 text-blue-950" /> : <Menu className="h-6 w-6 text-blue-950" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white px-4 py-3 lg:hidden">
          <div className="flex flex-col gap-1">
            {links.map((l) => (
              <button
                key={l.id}
                onClick={() => { goto(l.id); setOpen(false); }}
                className={`flex items-center gap-3 rounded-lg px-3 py-3 text-left text-sm font-semibold ${page === l.id ? "bg-blue-50 text-blue-900" : "text-slate-600"}`}
              >
                <l.icon className="h-4 w-4" /> {l.label}
              </button>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
            <CallButton label={CONFIG.callNumber} className="text-xs px-3 py-2.5" />
            <WhatsAppButton label="WhatsApp" className="text-xs px-3 py-2.5" />
          </div>
        </div>
      )}
    </header>
  );
}

/* ============================== FLOATING BUTTONS ============================== */

function FloatingContact() {
  return (
    <div className="fixed bottom-5 right-4 z-40 flex flex-col items-end gap-2.5 sm:bottom-6 sm:right-6">
      <a href={WA_LINK} target="_blank" rel="noopener noreferrer"
        className="group flex items-center gap-2 rounded-full bg-emerald-600 py-3 pl-3 pr-3 text-white shadow-lg transition-all hover:pr-4 sm:py-3.5">
        <MessageCircle className="h-5 w-5 shrink-0" />
        <span className="hidden max-w-0 overflow-hidden whitespace-nowrap text-sm font-semibold transition-all group-hover:max-w-[10rem] sm:inline-block">WhatsApp</span>
      </a>
      <a href={TEL_LINK}
        className="group flex items-center gap-2 rounded-full bg-blue-900 py-3 pl-3 pr-3 text-white shadow-lg transition-all hover:pr-4 sm:py-3.5">
        <Phone className="h-5 w-5 shrink-0" />
        <span className="hidden max-w-0 overflow-hidden whitespace-nowrap text-sm font-semibold transition-all group-hover:max-w-[10rem] sm:inline-block">Call</span>
      </a>
    </div>
  );
}

/* ============================== SUPPORT CARD (shared) ============================== */

function SupportCard({ title = "Need Help With Your Complaint?", subtitle = "Can't submit an issue or having trouble tracking your complaint?" }) {
  return (
    <div className="rounded-2xl border border-blue-900/10 bg-gradient-to-br from-blue-50 to-teal-50 p-6 sm:p-8">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-lg font-bold text-blue-950">{title}</p>
          <p className="mt-1 max-w-md text-sm text-slate-600">{subtitle}</p>
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm font-semibold text-slate-700">
            <span className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5 text-blue-900" /> {CONFIG.callNumber}</span>
            <span className="flex items-center gap-1.5"><MessageCircle className="h-3.5 w-3.5 text-emerald-600" /> {CONFIG.whatsappNumber}</span>
          </div>
        </div>
        <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
          <CallButton />
          <WhatsAppButton />
        </div>
      </div>
      <p className="mt-4 border-t border-blue-900/10 pt-3 text-xs text-slate-500">
        CivicConnect is a hackathon prototype and these contact numbers are provided for demonstration/support purposes. It is not an official government helpline.
      </p>
    </div>
  );
}

/* ============================== HOME PAGE ============================== */

function StatCard({ value, label, icon: Icon }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 text-center shadow-sm sm:p-6">
      <Icon className="mx-auto mb-2 h-5 w-5 text-teal-600" />
      <p className="text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">{value}</p>
      <p className="mt-1 text-xs font-medium text-slate-500 sm:text-sm">{label}</p>
    </div>
  );
}

function HotspotMap() {
  const markers = [
    { x: 30, y: 25, level: "High", area: "Tower Chowk" },
    { x: 62, y: 18, level: "Critical", area: "Station Road" },
    { x: 20, y: 55, level: "Medium", area: "Laheriasarai" },
    { x: 75, y: 48, level: "Low", area: "Donar" },
    { x: 48, y: 65, level: "High", area: "Kadirabad" },
    { x: 55, y: 38, level: "Medium", area: "University Area" },
    { x: 15, y: 78, level: "Critical", area: "Benta" },
  ];
  const color = { Critical: "bg-red-600", High: "bg-orange-500", Medium: "bg-amber-400", Low: "bg-emerald-500" };
  return (
    <div className="rounded-2xl border border-slate-200 bg-blue-950 p-4 sm:p-6">
      <div className="relative h-64 w-full overflow-hidden rounded-xl bg-blue-900/60 sm:h-80">
        <svg className="absolute inset-0 h-full w-full opacity-30" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M0,40 Q30,10 55,35 T100,25" stroke="#5eead4" strokeWidth="0.6" fill="none" />
          <path d="M0,70 Q40,50 70,72 T100,60" stroke="#5eead4" strokeWidth="0.6" fill="none" />
          <path d="M20,0 L25,100" stroke="#5eead4" strokeWidth="0.4" fill="none" />
          <path d="M65,0 L60,100" stroke="#5eead4" strokeWidth="0.4" fill="none" />
        </svg>
        {markers.map((m, i) => (
          <div key={i} className="absolute -translate-x-1/2 -translate-y-1/2" style={{ left: `${m.x}%`, top: `${m.y}%` }}>
            <span className={`block h-3 w-3 rounded-full ${color[m.level]} ring-4 ring-white/10`} />
          </div>
        ))}
        <p className="absolute bottom-2 left-2 text-[10px] font-semibold uppercase tracking-widest text-teal-200/60">Darbhanga — Stylized Overview</p>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs font-semibold text-slate-200">
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-red-600" /> Critical</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-orange-500" /> High</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-amber-400" /> Medium</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Low</span>
      </div>
    </div>
  );
}

function HomePage({ goto, complaints }) {
  const recent = complaints.slice(-6).reverse();
  const steps = [
    { n: "01", title: "Spot an Issue", desc: "Citizen notices a public problem in the neighbourhood.", icon: Eye },
    { n: "02", title: "Report It", desc: "Upload a photo, describe the problem and provide the location.", icon: Upload },
    { n: "03", title: "Track Progress", desc: "Use the complaint ID to monitor status anytime.", icon: Search },
    { n: "04", title: "Get It Resolved", desc: "Authorities update the complaint until resolution.", icon: CheckCircle2 },
  ];
  const trust = [
    { title: "Transparent Tracking", desc: "Citizens always know the current complaint status.", icon: Eye },
    { title: "Evidence Based", desc: "Photo and location help authorities verify issues.", icon: Camera },
    { title: "Priority Driven", desc: "Urgent public safety issues can be prioritized.", icon: AlertTriangle },
    { title: "Accountability", desc: "Every status update is recorded in the complaint timeline.", icon: ShieldCheck },
  ];

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-blue-950">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(45,212,191,0.15),transparent_60%)]" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 sm:py-20 lg:grid-cols-2 lg:items-center lg:py-24">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-teal-400/30 bg-teal-400/10 px-3 py-1 text-xs font-semibold text-teal-300">
              <MapPin className="h-3.5 w-3.5" /> Darbhanga, Bihar
            </span>
            <h1 className="mt-4 text-3xl font-extrabold leading-[1.1] tracking-tight text-white sm:text-4xl lg:text-5xl">
              Make Darbhanga Better, One Complaint at a Time.
            </h1>
            <p className="mt-4 max-w-lg text-base text-slate-300 sm:text-lg">
              Report potholes, broken streetlights, garbage, water leaks and other civic issues. Track your complaint and stay informed until the issue is resolved.
            </p>
            <p className="mt-2 text-sm font-medium text-teal-300/80">Report. Track. Resolve.</p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <PrimaryButton onClick={() => goto("report")} icon={PlusCircle} className="bg-teal-500 hover:bg-teal-400">Report an Issue</PrimaryButton>
              <SecondaryButton onClick={() => goto("track")} icon={Search} className="bg-white/5 text-white border-white/15 hover:bg-white/10">Track Complaint</SecondaryButton>
            </div>
          </div>
          <div className="relative">
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 shadow-2xl backdrop-blur sm:p-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <p className="text-xs font-bold uppercase tracking-widest text-teal-300">Authority Demo Dashboard</p>
                <BarChart3 className="h-4 w-4 text-teal-300" />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                {[["1,248+","Reported"],["936+","Resolved"],["184","In Progress"],["75%","Resolution"]].map(([v,l]) => (
                  <div key={l} className="rounded-xl bg-white/5 p-3">
                    <p className="text-xl font-extrabold text-white">{v}</p>
                    <p className="text-[11px] text-slate-300">{l}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 space-y-2">
                {recent.slice(0,3).map((c) => (
                  <div key={c.id} className="flex items-center justify-between rounded-lg bg-white/5 px-3 py-2 text-xs">
                    <span className="truncate text-slate-200">{c.title}</span>
                    <span className="ml-2 shrink-0 rounded-full bg-teal-400/20 px-2 py-0.5 font-semibold text-teal-300">{c.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <p className="mb-4 text-center text-xs font-semibold uppercase tracking-widest text-slate-400">Demonstration statistics</p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
          <StatCard value="1,248+" label="Issues Reported" icon={FileText} />
          <StatCard value="936+" label="Issues Resolved" icon={CheckCircle2} />
          <StatCard value="184" label="In Progress" icon={Clock} />
          <StatCard value="75%" label="Resolution Rate" icon={TrendingUp} />
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-slate-50 py-14 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionEyebrow>How CivicConnect Works</SectionEyebrow>
          <h2 className="max-w-lg text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">From a spotted problem to a resolved case — four simple stages.</h2>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((s) => (
              <div key={s.n} className="relative rounded-2xl border border-slate-200 bg-white p-5">
                <span className="font-mono text-xs font-bold text-teal-600/60">{s.n}</span>
                <div className="mt-3 flex h-10 w-10 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
                  <s.icon className="h-5 w-5" />
                </div>
                <p className="mt-3 font-bold text-blue-950">{s.title}</p>
                <p className="mt-1 text-sm text-slate-500">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-16">
        <SectionEyebrow>Issue Categories</SectionEyebrow>
        <h2 className="max-w-lg text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">Report the exact kind of problem you see.</h2>
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {CATEGORIES.map((c) => (
            <button key={c.id} onClick={() => goto("report", { presetCategory: c.id })} className="rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-teal-300 hover:shadow-md">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-900">
                <c.icon className="h-5 w-5" />
              </div>
              <p className="mt-3 text-sm font-bold text-blue-950">{c.label}</p>
              <p className="mt-1 text-xs text-slate-500">{c.desc}</p>
            </button>
          ))}
        </div>
      </section>

      {/* HOTSPOT MAP */}
      <section className="mx-auto max-w-7xl px-4 pb-14 sm:px-6 sm:pb-16">
        <SectionEyebrow>Issue Hotspots</SectionEyebrow>
        <h2 className="mb-6 max-w-lg text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">Where issues are being reported across Darbhanga.</h2>
        <HotspotMap />
      </section>

      {/* RECENT COMPLAINTS */}
      <section className="bg-slate-50 py-14 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionEyebrow>Recent Complaints</SectionEyebrow>
          <h2 className="mb-8 max-w-lg text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">Anonymized reports from fellow citizens.</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {recent.map((c) => (
              <button key={c.id} onClick={() => goto("details", { id: c.id })} className="rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-teal-300 hover:shadow-md">
                <div className="flex items-start justify-between">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-900">
                    <CategoryIcon id={c.category} className="h-4.5 w-4.5" />
                  </div>
                  <StatusBadge status={c.status} />
                </div>
                <p className="mt-3 text-sm font-bold text-blue-950">{c.title}</p>
                <p className="mt-1 flex items-center gap-1 text-xs text-slate-500"><MapPin className="h-3 w-3" /> {c.area}, Darbhanga</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* TRUST */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-16">
        <SectionEyebrow>Trust &amp; Transparency</SectionEyebrow>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {trust.map((t) => (
            <div key={t.title} className="rounded-2xl border border-slate-200 bg-white p-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
                <t.icon className="h-5 w-5" />
              </div>
              <p className="mt-3 font-bold text-blue-950">{t.title}</p>
              <p className="mt-1 text-sm text-slate-500">{t.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SUPPORT CARD */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
        <SupportCard />
      </section>
    </div>
  );
}

/* ============================== REPORT ISSUE PAGE ============================== */

function ReportIssuePage({ goto, addComplaint, presetCategory }) {
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState(presetCategory || "");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState(null);
  const [area, setArea] = useState("");
  const [landmark, setLandmark] = useState("");
  const [address, setAddress] = useState("");
  const [pincode, setPincode] = useState("");
  const [priority, setPriority] = useState("");
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(null);
  const fileRef = useRef(null);

  const DESC_MAX = 500;

  function validateStep() {
    const e = {};
    if (step === 1 && !category) e.category = "Please select a category to continue.";
    if (step === 2) {
      if (!title.trim()) e.title = "Issue title is required.";
      if (!description.trim()) e.description = "Please describe the issue.";
    }
    if (step === 4) {
      if (!area.trim()) e.area = "Area is required.";
      if (!address.trim()) e.address = "Full address is required.";
      if (!pincode.trim() || pincode.trim().length < 6) e.pincode = "Enter a valid 6-digit pincode.";
    }
    if (step === 5 && !priority) e.priority = "Please select a priority level.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function next() { if (validateStep()) setStep((s) => Math.min(5, s + 1)); }
  function back() { setStep((s) => Math.max(1, s - 1)); }

  function onFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setImage(reader.result);
    reader.readAsDataURL(f);
  }

  async function submit() {
    if (!validateStep()) return;
    setSubmitting(true);
    const complaint = {
      category, title: title.trim(), description: description.trim(), image,
      area, landmark, address, pincode, priority,
    };
    await new Promise((r) => setTimeout(r, 600));
    const created = addComplaint(complaint);
    setSubmitting(false);
    setSubmitted(created);
  }

  if (submitted) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-14 sm:px-6">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-6 text-center sm:p-10">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100">
            <CheckCircle2 className="h-8 w-8 text-emerald-600" />
          </div>
          <h2 className="text-xl font-extrabold text-blue-950 sm:text-2xl">Complaint Submitted Successfully</h2>
          <p className="mt-1 text-sm text-slate-600">Your complaint has been registered.</p>
          <div className="mt-5 flex justify-center"><TicketStamp id={submitted.id} /></div>

          <div className="mt-6 grid gap-3 rounded-xl bg-white p-5 text-left sm:grid-cols-2">
            <div><p className="text-xs font-semibold uppercase text-slate-400">Category</p><p className="text-sm font-semibold text-blue-950">{catById(submitted.category).label}</p></div>
            <div><p className="text-xs font-semibold uppercase text-slate-400">Location</p><p className="text-sm font-semibold text-blue-950">{submitted.area}, Darbhanga</p></div>
            <div><p className="text-xs font-semibold uppercase text-slate-400">Priority</p><PriorityBadge priority={submitted.priority} /></div>
            <div><p className="text-xs font-semibold uppercase text-slate-400">Current Status</p><StatusBadge status={submitted.status} /></div>
          </div>

          <div className="mt-6 flex flex-col gap-2 sm:flex-row">
            <PrimaryButton full icon={Search} onClick={() => goto("track", { prefillId: submitted.id })}>Track Complaint</PrimaryButton>
            <SecondaryButton full icon={PlusCircle} onClick={() => { setSubmitted(null); setStep(1); setCategory(""); setTitle(""); setDescription(""); setImage(null); setArea(""); setLandmark(""); setAddress(""); setPincode(""); setPriority(""); }}>
              Report Another Issue
            </SecondaryButton>
          </div>
          <p className="mt-6 mb-2 text-xs font-semibold uppercase tracking-widest text-slate-400">If you need assistance regarding this complaint</p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <CallButton className="flex-1" label={`Call: ${CONFIG.callNumber}`} />
            <WhatsAppButton className="flex-1" label="WhatsApp Support" />
          </div>
        </div>
      </div>
    );
  }

  const steps = ["Category", "Describe", "Evidence", "Location", "Priority"];

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
      <SectionEyebrow>Report an Issue</SectionEyebrow>
      <h1 className="text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">Tell us what's wrong and where.</h1>

      {/* Stepper */}
      <div className="mt-6 flex items-center gap-1.5 sm:gap-2">
        {steps.map((s, i) => (
          <React.Fragment key={s}>
            <div className="flex flex-col items-center gap-1">
              <div className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${step === i + 1 ? "bg-teal-600 text-white" : step > i + 1 ? "bg-teal-100 text-teal-700" : "bg-slate-100 text-slate-400"}`}>
                {step > i + 1 ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
              </div>
              <span className="hidden text-[10px] font-semibold text-slate-500 sm:block">{s}</span>
            </div>
            {i < steps.length - 1 && <div className={`h-0.5 flex-1 ${step > i + 1 ? "bg-teal-400" : "bg-slate-200"}`} />}
          </React.Fragment>
        ))}
      </div>

      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 sm:p-8">
        {step === 1 && (
          <div>
            <p className="mb-4 font-bold text-blue-950">Select a category</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {CATEGORIES.map((c) => (
                <button key={c.id} onClick={() => setCategory(c.id)}
                  className={`flex flex-col items-start gap-2 rounded-xl border-2 p-3 text-left transition ${category === c.id ? "border-teal-500 bg-teal-50" : "border-slate-200 hover:border-slate-300"}`}>
                  <c.icon className={`h-5 w-5 ${category === c.id ? "text-teal-700" : "text-blue-900"}`} />
                  <span className="text-xs font-bold text-blue-950">{c.label}</span>
                </button>
              ))}
            </div>
            {errors.category && <p className="mt-2 text-xs font-semibold text-red-600">{errors.category}</p>}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5">
            <div>
              <label className="mb-1.5 block text-sm font-bold text-blue-950">Issue Title</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Large pothole near main road"
                className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
              {errors.title && <p className="mt-1 text-xs font-semibold text-red-600">{errors.title}</p>}
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-bold text-blue-950">Description</label>
              <textarea value={description} maxLength={DESC_MAX} onChange={(e) => setDescription(e.target.value)} rows={5}
                placeholder="Describe the issue in detail — what you saw, since when, and any risk it poses."
                className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
              <div className="mt-1 flex items-center justify-between">
                {errors.description ? <p className="text-xs font-semibold text-red-600">{errors.description}</p> : <span />}
                <p className="text-xs text-slate-400">{description.length}/{DESC_MAX}</p>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <p className="mb-4 font-bold text-blue-950">Upload Evidence</p>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
              <div className="flex h-40 w-full items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 sm:w-56">
                {image ? <img src={image} alt="Evidence preview" className="h-full w-full object-cover" /> : (
                  <div className="flex flex-col items-center gap-1.5 text-slate-400">
                    <ImageIcon className="h-8 w-8" />
                    <p className="text-xs font-medium">No image uploaded</p>
                  </div>
                )}
              </div>
              <div className="flex-1">
                <input ref={fileRef} type="file" accept="image/*" onChange={onFile} className="hidden" />
                <SecondaryButton icon={Camera} onClick={() => fileRef.current?.click()}>{image ? "Change Photo" : "Upload Photo"}</SecondaryButton>
                <p className="mt-2 text-xs text-slate-500">A clear photo helps authorities verify and prioritize your complaint faster. This step is optional.</p>
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2 flex items-center gap-2 rounded-xl bg-blue-50 px-4 py-3 text-sm font-semibold text-blue-900">
              <MapPin className="h-4 w-4 shrink-0" /> Laheriasarai, Darbhanga, Bihar — approximate demo location
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-bold text-blue-950">Area</label>
              <select value={area} onChange={(e) => setArea(e.target.value)} className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100">
                <option value="">Select area</option>
                {AREAS.map((a) => <option key={a} value={a}>{a}</option>)}
              </select>
              {errors.area && <p className="mt-1 text-xs font-semibold text-red-600">{errors.area}</p>}
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-bold text-blue-950">Landmark</label>
              <input value={landmark} onChange={(e) => setLandmark(e.target.value)} placeholder="e.g. Near Sadar Hospital"
                className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
            </div>
            <div className="sm:col-span-2">
              <label className="mb-1.5 block text-sm font-bold text-blue-950">Full Address</label>
              <textarea value={address} onChange={(e) => setAddress(e.target.value)} rows={2}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
              {errors.address && <p className="mt-1 text-xs font-semibold text-red-600">{errors.address}</p>}
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-bold text-blue-950">Pincode</label>
              <input value={pincode} onChange={(e) => setPincode(e.target.value.replace(/\D/g, "").slice(0,6))} placeholder="846001"
                className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
              {errors.pincode && <p className="mt-1 text-xs font-semibold text-red-600">{errors.pincode}</p>}
            </div>
          </div>
        )}

        {step === 5 && (
          <div>
            <p className="mb-4 font-bold text-blue-950">Select Priority</p>
            <div className="grid gap-3 sm:grid-cols-2">
              {PRIORITIES.map((p) => (
                <button key={p.id} onClick={() => setPriority(p.id)}
                  className={`flex items-start gap-3 rounded-xl border-2 p-4 text-left transition ${priority === p.id ? "border-teal-500 bg-teal-50" : "border-slate-200 hover:border-slate-300"}`}>
                  <span className={`mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${p.dot}`} />
                  <span>
                    <span className="block text-sm font-bold text-blue-950">{p.id}</span>
                    <span className="block text-xs text-slate-500">{p.desc}</span>
                  </span>
                </button>
              ))}
            </div>
            {errors.priority && <p className="mt-2 text-xs font-semibold text-red-600">{errors.priority}</p>}
          </div>
        )}

        <div className="mt-8 flex items-center justify-between gap-3 border-t border-slate-100 pt-5">
          {step > 1 ? <SecondaryButton icon={ArrowLeft} onClick={back}>Back</SecondaryButton> : <span />}
          {step < 5 ? (
            <PrimaryButton icon={ArrowRight} onClick={next}>Continue</PrimaryButton>
          ) : (
            <PrimaryButton icon={submitting ? Loader2 : Send} onClick={submit} className={submitting ? "opacity-80" : ""}>
              {submitting ? "Submitting..." : "Submit Complaint"}
            </PrimaryButton>
          )}
        </div>
      </div>

      <div className="mt-10 rounded-2xl border border-slate-200 bg-slate-50 p-5 sm:p-6">
        <p className="font-bold text-blue-950">Need Assistance?</p>
        <p className="mt-1 text-sm text-slate-500">If you are unable to submit your complaint online, contact CivicConnect support.</p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <CallButton className="flex-1" label={`${CONFIG.callNumber} — Call`} />
          <WhatsAppButton className="flex-1" label={`${CONFIG.whatsappNumber} — WhatsApp`} />
        </div>
      </div>
    </div>
  );
}

/* ============================== TRACK COMPLAINT PAGE ============================== */

function TrackComplaintPage({ goto, complaints, prefillId }) {
  const [query, setQuery] = useState(prefillId || "");
  const [result, setResult] = useState(null);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    if (prefillId) doSearch(prefillId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefillId]);

  function doSearch(q) {
    const val = (q ?? query).trim().toUpperCase();
    setSearched(true);
    const found = complaints.find((c) => c.id.toUpperCase() === val);
    setResult(found || null);
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
      <SectionEyebrow>Track Your Complaint</SectionEyebrow>
      <h1 className="text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">Track Your Complaint</h1>
      <p className="mt-2 text-sm text-slate-500">Enter your complaint ID to see the latest status and timeline.</p>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. CC-DAR-2026-1042"
          onKeyDown={(e) => e.key === "Enter" && doSearch()}
          className="flex-1 rounded-xl border border-slate-300 px-4 py-3 font-mono text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
        <PrimaryButton icon={Search} onClick={() => doSearch()}>Track Complaint</PrimaryButton>
      </div>

      {searched && !result && (
        <div className="mt-8"><EmptyState icon={XCircle} title="No complaint found" subtitle="Please double-check the complaint ID and try again." /></div>
      )}

      {result && (
        <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <TicketStamp id={result.id} compact />
            <StatusBadge status={result.status} size="md" />
          </div>
          <h2 className="mt-4 text-lg font-extrabold text-blue-950">{result.title}</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="Category" value={catById(result.category).label} />
            <Field label="Location" value={`${result.area}, Darbhanga`} />
            <Field label="Submitted Date" value={result.createdAt} />
            <Field label="Priority" value={<PriorityBadge priority={result.priority} />} />
            <Field label="Assigned Department" value={result.department || "Not yet assigned"} />
            <Field label="Current Status" value={<StatusBadge status={result.status} />} />
          </div>
          <div className="mt-8">
            <p className="mb-5 font-bold text-blue-950">Status Timeline</p>
            <ComplaintTimeline timeline={result.timeline} status={result.status} />
          </div>
          <div className="mt-8">
            <SecondaryButton icon={ChevronRight} onClick={() => goto("details", { id: result.id })}>View Full Details</SecondaryButton>
          </div>
        </div>
      )}

      <div className="mt-10 rounded-2xl border border-slate-200 bg-slate-50 p-5 sm:p-6">
        <p className="font-bold text-blue-950">Can't Find Your Complaint?</p>
        <p className="mt-1 text-sm text-slate-500">If you are having difficulty tracking your complaint, contact support.</p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <CallButton className="flex-1" label="Call Now" />
          <WhatsAppButton className="flex-1" label="Chat on WhatsApp" />
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
      <div className="mt-1 text-sm font-semibold text-blue-950">{value}</div>
    </div>
  );
}

/* ============================== COMPLAINT DETAILS PAGE ============================== */

function ComplaintDetailsPage({ goto, complaints, id }) {
  const complaint = complaints.find((c) => c.id === id);
  if (!complaint) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-14 sm:px-6">
        <EmptyState icon={XCircle} title="Complaint not found" subtitle="This complaint may not exist. Try tracking it again." />
        <div className="mt-6 flex justify-center"><SecondaryButton icon={ArrowLeft} onClick={() => goto("track")}>Back to Track Complaint</SecondaryButton></div>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14">
      <button onClick={() => goto("track")} className="mb-6 flex items-center gap-1.5 text-sm font-semibold text-slate-500 hover:text-blue-900">
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <TicketStamp id={complaint.id} />
        <StatusBadge status={complaint.status} size="md" />
      </div>

      <h1 className="mt-5 text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">{complaint.title}</h1>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
            <p className="mb-3 font-bold text-blue-950">Description</p>
            <p className="text-sm leading-relaxed text-slate-600">{complaint.description}</p>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Field label="Category" value={<span className="flex items-center gap-1.5"><CategoryIcon id={complaint.category} className="h-4 w-4" /> {catById(complaint.category).label}</span>} />
              <Field label="Priority" value={<PriorityBadge priority={complaint.priority} />} />
              <Field label="Location" value={complaint.address || `${complaint.area}, Darbhanga, Bihar`} />
              <Field label="Assigned Department" value={complaint.department || "Not yet assigned"} />
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
            <p className="mb-3 font-bold text-blue-950">Citizen Evidence</p>
            {complaint.image ? (
              <img src={complaint.image} alt="Citizen evidence" className="max-h-72 w-full rounded-xl object-cover" />
            ) : (
              <div className="flex h-40 items-center justify-center rounded-xl border-2 border-dashed border-slate-200 bg-slate-50 text-slate-400">
                <div className="text-center"><ImageIcon className="mx-auto mb-1 h-7 w-7" /><p className="text-xs">No image was uploaded</p></div>
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
            <p className="mb-5 font-bold text-blue-950">Timeline</p>
            <ComplaintTimeline timeline={complaint.timeline} status={complaint.status} />
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
            <p className="mb-3 font-bold text-blue-950">Resolution</p>
            {complaint.resolution ? (
              <div>
                <p className="text-sm text-slate-600">{complaint.resolution.note}</p>
                {complaint.resolution.proofImage ? (
                  <img src={complaint.resolution.proofImage} alt="Resolution proof" className="mt-3 max-h-56 w-full rounded-xl object-cover" />
                ) : (
                  <div className="mt-3 flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-400"><ImageIcon className="h-4 w-4" /> No proof image provided</div>
                )}
                <p className="mt-3 flex items-center gap-1.5 text-sm font-semibold text-emerald-700"><CheckCircle2 className="h-4 w-4" /> Issue resolved successfully</p>
                <p className="mt-2 text-xs text-slate-400">Resolution information shown in this prototype is demonstration data.</p>
              </div>
            ) : (
              <p className="text-sm text-slate-400">Resolution details will appear here once the issue has been resolved by the concerned department.</p>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <p className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-400">At a Glance</p>
            <div className="space-y-3">
              <Field label="Submitted" value={complaint.createdAt} />
              <Field label="Status" value={<StatusBadge status={complaint.status} />} />
              <Field label="Priority" value={<PriorityBadge priority={complaint.priority} />} />
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <p className="font-bold text-blue-950">Need Help With This Complaint?</p>
            <p className="mt-1 text-sm text-slate-500">For assistance regarding complaint status or submission:</p>
            <div className="mt-4 flex flex-col gap-2">
              <CallButton label={`Call: ${CONFIG.callNumber}`} />
              <WhatsAppButton label={`WhatsApp: ${CONFIG.whatsappNumber}`} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================== AUTHORITY DASHBOARD ============================== */

const CHART_COLORS = ["#0f3b5c","#0d9488","#f97316","#dc2626","#64748b","#0ea5e9","#16a34a","#a855f7","#eab308","#f43f5e"];

function AuthorityDashboardPage({ complaints, updateComplaint, goto }) {
  const [catFilter, setCatFilter] = useState("All");
  const [prioFilter, setPrioFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  const stats = useMemo(() => {
    const total = complaints.length;
    const byStatus = (s) => complaints.filter((c) => c.status === s).length;
    const critical = complaints.filter((c) => c.priority === "Critical").length;
    const resolved = byStatus("Resolved") + byStatus("Closed");
    return {
      total,
      newReports: byStatus("Reported"),
      verified: byStatus("Verified"),
      assigned: byStatus("Assigned"),
      inProgress: byStatus("In Progress"),
      resolved,
      critical,
      rate: total ? Math.round((resolved / total) * 100) : 0,
    };
  }, [complaints]);

  const filtered = useMemo(() => {
    return complaints.filter((c) => {
      if (catFilter !== "All" && c.category !== catFilter) return false;
      if (prioFilter !== "All" && c.priority !== prioFilter) return false;
      if (statusFilter !== "All" && c.status !== statusFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        if (!(c.id.toLowerCase().includes(q) || c.title.toLowerCase().includes(q) || c.area.toLowerCase().includes(q))) return false;
      }
      return true;
    }).slice().reverse();
  }, [complaints, catFilter, prioFilter, statusFilter, search]);

  const categoryChartData = useMemo(() => CATEGORIES.map((c) => ({ name: c.label.split(" / ")[0], count: complaints.filter((x) => x.category === c.id).length })).filter((d) => d.count > 0), [complaints]);
  const statusChartData = useMemo(() => STATUS_FLOW.map((s) => ({ name: s, value: complaints.filter((c) => c.status === s).length })).filter((d) => d.value > 0), [complaints]);
  const priorityChartData = useMemo(() => PRIORITIES.map((p) => ({ name: p.id, value: complaints.filter((c) => c.priority === p.id).length })).filter((d) => d.value > 0), [complaints]);
  const areaChartData = useMemo(() => AREAS.map((a) => ({ name: a, count: complaints.filter((c) => c.area === a).length })).sort((a,b) => b.count - a.count), [complaints]);

  const statCards = [
    { label: "Total Complaints", value: stats.total, icon: FileText },
    { label: "New Reports", value: stats.newReports, icon: PlusCircle },
    { label: "Verified", value: stats.verified, icon: CheckCircle },
    { label: "Assigned", value: stats.assigned, icon: Users },
    { label: "In Progress", value: stats.inProgress, icon: Clock },
    { label: "Resolved", value: stats.resolved, icon: CheckCircle2 },
    { label: "Critical Issues", value: stats.critical, icon: AlertTriangle },
    { label: "Resolution Rate", value: `${stats.rate}%`, icon: TrendingUp },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1 text-xs font-bold uppercase tracking-wide text-blue-900">
            <ShieldCheck className="h-3.5 w-3.5" /> Authority Demo Dashboard
          </span>
          <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-blue-950 sm:text-3xl">Complaint Management</h1>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {statCards.map((s) => (
          <div key={s.label} className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="flex items-center justify-between">
              <s.icon className="h-4 w-4 text-teal-600" />
            </div>
            <p className="mt-2 text-xl font-extrabold text-blue-950 sm:text-2xl">{s.value}</p>
            <p className="text-xs font-medium text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="mt-8 grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <p className="mb-4 flex items-center gap-2 font-bold text-blue-950"><BarChart3 className="h-4 w-4 text-teal-600" /> Complaints by Category</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={categoryChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#0d9488" radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <p className="mb-4 font-bold text-blue-950">Complaints by Status</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={statusChartData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                {statusChartData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip /><Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <p className="mb-4 font-bold text-blue-950">Priority Distribution</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={priorityChartData} dataKey="value" nameKey="name" outerRadius={80} label={{ fontSize: 11 }}>
                {priorityChartData.map((entry, i) => {
                  const colorMap = { Low: "#94a3b8", Medium: "#f59e0b", High: "#f97316", Critical: "#dc2626" };
                  return <Cell key={i} fill={colorMap[entry.name] || CHART_COLORS[i]} />;
                })}
              </Pie>
              <Tooltip /><Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <p className="mb-4 font-bold text-blue-950">Complaints by Area</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={areaChartData} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={90} />
              <Tooltip />
              <Bar dataKey="count" fill="#0f3b5c" radius={[0,6,6,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Filters */}
      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3 sm:hidden">
          <p className="font-bold text-blue-950">Filters</p>
          <button onClick={() => setShowFilters((v) => !v)} className="flex items-center gap-1 text-sm font-semibold text-teal-700">
            <Filter className="h-4 w-4" /> {showFilters ? "Hide" : "Show"}
          </button>
        </div>
        <div className={`${showFilters ? "grid" : "hidden"} mt-3 grid-cols-1 gap-3 sm:mt-0 sm:grid sm:grid-cols-2 lg:grid-cols-4`}>
          <div className="relative sm:col-span-2 lg:col-span-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search ID, title, location"
              className="w-full rounded-xl border border-slate-300 py-2.5 pl-9 pr-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-100" />
          </div>
          <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-teal-500 focus:outline-none">
            <option value="All">All Categories</option>
            {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
          <select value={prioFilter} onChange={(e) => setPrioFilter(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-teal-500 focus:outline-none">
            <option value="All">All Priorities</option>
            {PRIORITIES.map((p) => <option key={p.id} value={p.id}>{p.id}</option>)}
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-teal-500 focus:outline-none">
            <option value="All">All Statuses</option>
            {STATUS_FLOW.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {/* Table (desktop) / Cards (mobile) */}
      <div className="mt-6">
        {filtered.length === 0 ? (
          <EmptyState icon={Search} title="No complaints match your filters" subtitle="Try adjusting your search or filters." />
        ) : (
          <>
            <div className="hidden overflow-hidden rounded-2xl border border-slate-200 bg-white lg:block">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-xs font-bold uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-4 py-3">Complaint ID</th>
                    <th className="px-4 py-3">Issue</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Location</th>
                    <th className="px-4 py-3">Priority</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Department</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50/70">
                      <td className="px-4 py-3 font-mono text-xs font-bold text-blue-900">{c.id}</td>
                      <td className="max-w-[220px] truncate px-4 py-3 font-medium text-slate-700">{c.title}</td>
                      <td className="px-4 py-3 text-slate-600">{catById(c.category).label}</td>
                      <td className="px-4 py-3 text-slate-600">{c.area}</td>
                      <td className="px-4 py-3"><PriorityBadge priority={c.priority} /></td>
                      <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                      <td className="px-4 py-3 text-slate-600">{c.department || "—"}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-slate-500">{c.createdAt.split(",")[0]}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => setSelected(c)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-blue-900 hover:bg-blue-50">Manage</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="grid gap-3 lg:hidden">
              {filtered.map((c) => (
                <div key={c.id} className="rounded-2xl border border-slate-200 bg-white p-4">
                  <div className="flex items-start justify-between">
                    <p className="font-mono text-xs font-bold text-blue-900">{c.id}</p>
                    <StatusBadge status={c.status} />
                  </div>
                  <p className="mt-2 text-sm font-bold text-blue-950">{c.title}</p>
                  <p className="mt-1 flex items-center gap-1 text-xs text-slate-500"><MapPin className="h-3 w-3" /> {c.area}, Darbhanga</p>
                  <div className="mt-2 flex items-center justify-between">
                    <PriorityBadge priority={c.priority} />
                    <span className="text-xs text-slate-400">{c.createdAt.split(",")[0]}</span>
                  </div>
                  <button onClick={() => setSelected(c)} className="mt-3 w-full rounded-lg border border-slate-200 py-2 text-xs font-semibold text-blue-900 hover:bg-blue-50">Manage Complaint</button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {selected && (
        <ManageComplaintModal complaint={selected} onClose={() => setSelected(null)}
          onUpdate={(patch) => { updateComplaint(selected.id, patch); setSelected((s) => ({ ...s, ...patch })); }}
          goto={goto} />
      )}
    </div>
  );
}

function ManageComplaintModal({ complaint, onClose, onUpdate, goto }) {
  const [department, setDepartment] = useState(complaint.department || "");
  const [officer, setOfficer] = useState(complaint.officer || "");
  const [status, setStatus] = useState(complaint.status);
  const [resolutionNote, setResolutionNote] = useState(complaint.resolution?.note || "");
  const [proofImage, setProofImage] = useState(complaint.resolution?.proofImage || null);
  const fileRef = useRef(null);

  function onProofFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setProofImage(reader.result);
    reader.readAsDataURL(f);
  }

  function saveAssignment() {
    onUpdate({ department, officer });
  }

  function saveStatus() {
    const idx = STATUS_FLOW.indexOf(status);
    const timeline = complaint.timeline.filter((t) => STATUS_FLOW.indexOf(t.status) < idx);
    const now = new Date();
    for (let i = timeline.length; i <= idx; i++) {
      timeline.push({ status: STATUS_FLOW[i], date: fmtDateTime(now), note: STATUS_NOTES[STATUS_FLOW[i]] });
    }
    const patch = { status, timeline };
    if (status === "Resolved" || status === "Closed") {
      patch.resolution = { note: resolutionNote || "Issue resolved by the concerned department.", proofImage };
    }
    onUpdate(patch);
  }

  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/40 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="max-h-[92vh] w-full overflow-y-auto rounded-t-2xl bg-white p-5 shadow-2xl sm:max-w-2xl sm:rounded-2xl sm:p-7">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-mono text-xs font-bold text-blue-900">{complaint.id}</p>
            <p className="mt-1 text-lg font-extrabold text-blue-950">{complaint.title}</p>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <StatusBadge status={complaint.status} />
          <PriorityBadge priority={complaint.priority} />
          <span className="rounded-full border border-slate-200 px-2.5 py-0.5 text-xs font-semibold text-slate-600">{complaint.area}</span>
        </div>

        {/* Assign */}
        <div className="mt-6 rounded-xl border border-slate-200 p-4">
          <p className="mb-3 flex items-center gap-2 font-bold text-blue-950"><Building2 className="h-4 w-4 text-teal-600" /> Assign Complaint</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-500">Assigned Department</label>
              <select value={department} onChange={(e) => setDepartment(e.target.value)} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none">
                <option value="">Select department</option>
                {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-500">Assigned Officer (optional)</label>
              <input value={officer} onChange={(e) => setOfficer(e.target.value)} placeholder="Officer name"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none" />
            </div>
          </div>
          <SecondaryButton className="mt-3 px-4 py-2 text-xs" onClick={saveAssignment}>Save Assignment</SecondaryButton>
        </div>

        {/* Status */}
        <div className="mt-4 rounded-xl border border-slate-200 p-4">
          <p className="mb-3 flex items-center gap-2 font-bold text-blue-950"><RefreshCw className="h-4 w-4 text-teal-600" /> Update Complaint Status</p>
          <div className="flex flex-wrap gap-2">
            {STATUS_FLOW.map((s) => (
              <button key={s} onClick={() => setStatus(s)}
                className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${status === s ? "border-teal-600 bg-teal-600 text-white" : "border-slate-200 text-slate-600 hover:border-teal-300"}`}>
                {s}
              </button>
            ))}
          </div>

          {(status === "Resolved" || status === "Closed") && (
            <div className="mt-4 rounded-lg bg-emerald-50/60 p-3">
              <p className="mb-2 text-xs font-bold uppercase tracking-wide text-emerald-700">Resolution Details</p>
              <textarea value={resolutionNote} onChange={(e) => setResolutionNote(e.target.value)} rows={3} placeholder="Describe the action taken..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none" />
              <div className="mt-2 flex items-center gap-3">
                <input ref={fileRef} type="file" accept="image/*" onChange={onProofFile} className="hidden" />
                <SecondaryButton className="px-3 py-1.5 text-xs" icon={Camera} onClick={() => fileRef.current?.click()}>
                  {proofImage ? "Change Proof" : "Upload Resolution Proof"}
                </SecondaryButton>
                {proofImage && <img src={proofImage} alt="proof" className="h-12 w-12 rounded-lg object-cover" />}
              </div>
              <p className="mt-2 text-[11px] text-slate-500">"Resolution information shown in this prototype is demonstration data."</p>
            </div>
          )}

          <PrimaryButton className="mt-4 px-4 py-2 text-xs" onClick={saveStatus}>Save Status Update</PrimaryButton>
        </div>

        <div className="mt-4 flex justify-end">
          <SecondaryButton icon={Eye} onClick={() => { onClose(); goto("details", { id: complaint.id }); }}>View Full Complaint Page</SecondaryButton>
        </div>
      </div>
    </div>
  );
}

/* ============================== ABOUT PAGE ============================== */

function AboutPage({ goto }) {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 sm:py-16">
      <SectionEyebrow>About CivicConnect</SectionEyebrow>
      <h1 className="text-2xl font-extrabold tracking-tight text-blue-950 sm:text-4xl">A transparent digital bridge between citizens and civic authorities.</h1>
      <p className="mt-4 text-base leading-relaxed text-slate-600">
        CivicConnect gives citizens of Darbhanga a simple, structured and transparent way to report public issues — potholes,
        broken streetlights, garbage, water leakage, drainage problems and more — with photographic evidence and precise
        location details. Every complaint receives a unique complaint ID that can be tracked from submission through to resolution.
      </p>
      <p className="mt-4 text-base leading-relaxed text-slate-600">
        On the other side, local authorities get an organized dashboard to review, verify, prioritize, assign and resolve
        complaints — with every status change recorded in a public timeline so residents always know where their complaint stands.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <ShieldCheck className="h-5 w-5 text-teal-600" />
          <p className="mt-3 font-bold text-blue-950">Hackathon Prototype</p>
          <p className="mt-1 text-sm text-slate-500">This is a demonstration build using mock data and browser storage — not a production government system.</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <Info className="h-5 w-5 text-teal-600" />
          <p className="mt-3 font-bold text-blue-950">Not an Official Body</p>
          <p className="mt-1 text-sm text-slate-500">CivicConnect is not officially connected to Darbhanga Municipal Corporation or any government authority.</p>
        </div>
      </div>

      <div className="mt-10 flex flex-col gap-3 sm:flex-row">
        <PrimaryButton icon={PlusCircle} onClick={() => goto("report")}>Report an Issue</PrimaryButton>
        <SecondaryButton icon={Search} onClick={() => goto("track")}>Track Complaint</SecondaryButton>
      </div>

      <div className="mt-10"><SupportCard title="Questions about CivicConnect?" subtitle="Reach the demo support line for anything related to the prototype." /></div>
    </div>
  );
}

/* ============================== FOOTER ============================== */

function Footer({ goto }) {
  return (
    <footer className="border-t border-slate-200 bg-blue-950 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500/20">
                <ShieldCheck className="h-4.5 w-4.5 text-teal-300" />
              </div>
              <p className="text-lg font-extrabold text-white">CivicConnect</p>
            </div>
            <p className="mt-3 text-sm text-slate-400">Building a cleaner, safer and more responsive Darbhanga through citizen participation.</p>
            <p className="mt-4 flex items-center gap-1.5 text-xs text-slate-400"><MapPin className="h-3.5 w-3.5" /> Darbhanga, Bihar</p>
            <span className="mt-3 inline-block rounded-full border border-white/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-teal-300">Hackathon Prototype</span>
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Navigate</p>
            <ul className="mt-3 space-y-2 text-sm">
              {[["report","Report Issue"],["track","Track Complaint"],["dashboard","Authority Dashboard"],["about","About"]].map(([id,label]) => (
                <li key={id}><button onClick={() => goto(id)} className="hover:text-teal-300">{label}</button></li>
              ))}
              <li><span className="cursor-default text-slate-500">Privacy</span></li>
              <li><span className="cursor-default text-slate-500">Terms</span></li>
            </ul>
          </div>

          <div className="sm:col-span-2 lg:col-span-2">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Complaint Support</p>
            <div className="mt-3 space-y-3">
              <div>
                <p className="flex items-center gap-1.5 text-sm text-white"><Phone className="h-3.5 w-3.5 text-teal-300" /> {CONFIG.callNumber} <span className="text-slate-400">— Call for Complaint</span></p>
              </div>
              <div>
                <p className="flex items-center gap-1.5 text-sm text-white"><MessageCircle className="h-3.5 w-3.5 text-teal-300" /> {CONFIG.whatsappNumber} <span className="text-slate-400">— WhatsApp Complaint</span></p>
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                <a href={TEL_LINK} className="rounded-lg bg-white/10 px-4 py-2 text-xs font-semibold text-white hover:bg-white/20">Call Now</a>
                <a href={WA_LINK} target="_blank" rel="noopener noreferrer" className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700">WhatsApp</a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-6 text-center text-xs text-slate-500">
          © 2026 CivicConnect · Darbhanga, Bihar · Hackathon Prototype — not an official government service.
        </div>
      </div>
    </footer>
  );
}

/* ============================== APP ============================== */

export default function App() {
  const [page, setPage] = useState("home");
  const [params, setParams] = useState({});
  const [complaints, setComplaints] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [toasts, setToasts] = useState([]);
  const saveTimer = useRef(null);

  const pushToast = useCallback((message) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  const goto = useCallback((p, prm = {}) => {
    setPage(p);
    setParams(prm);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem("cc_complaints");
      if (raw) {
        setComplaints(JSON.parse(raw));
      } else {
        const seed = generateSeedComplaints();
        setComplaints(seed);
        try { window.localStorage.setItem("cc_complaints", JSON.stringify(seed)); } catch (e) {}
      }
    } catch (e) {
      setComplaints(generateSeedComplaints());
    } finally {
      setLoaded(true);
    }
  }, []);

  // Persist on change (debounced)
  useEffect(() => {
    if (!loaded) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      try { window.localStorage.setItem("cc_complaints", JSON.stringify(complaints)); } catch (e) {}
    }, 400);
    return () => clearTimeout(saveTimer.current);
  }, [complaints, loaded]);

  const addComplaint = useCallback((data) => {
    let created;
    setComplaints((prev) => {
      const id = genComplaintId(prev);
      const now = new Date();
      created = {
        id,
        category: data.category,
        title: data.title,
        description: data.description,
        image: data.image || null,
        area: data.area,
        landmark: data.landmark,
        address: data.address,
        pincode: data.pincode,
        priority: data.priority,
        status: "Reported",
        department: null,
        officer: null,
        timeline: [{ status: "Reported", date: fmtDateTime(now), note: STATUS_NOTES["Reported"] }],
        resolution: null,
        createdAt: fmtDateTime(now),
      };
      return [...prev, created];
    });
    // created is set synchronously above (functional update runs immediately in this render cycle for our purposes)
    return created;
  }, []);

  const updateComplaint = useCallback((id, patch) => {
    setComplaints((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
    pushToast(`${id} updated successfully.`);
  }, [pushToast]);

  if (!loaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-7 w-7 animate-spin text-teal-600" />
          <p className="text-sm font-medium text-slate-500">Loading CivicConnect…</p>
        </div>
      </div>
    );
  }

  let content;
  if (page === "home") content = <HomePage goto={goto} complaints={complaints} />;
  else if (page === "report") content = <ReportIssuePage goto={goto} addComplaint={addComplaint} presetCategory={params.presetCategory} />;
  else if (page === "track") content = <TrackComplaintPage goto={goto} complaints={complaints} prefillId={params.prefillId || params.id} />;
  else if (page === "dashboard") content = <AuthorityDashboardPage complaints={complaints} updateComplaint={updateComplaint} goto={goto} />;
  else if (page === "details") content = <ComplaintDetailsPage goto={goto} complaints={complaints} id={params.id} />;
  else if (page === "about") content = <AboutPage goto={goto} />;
  else content = <HomePage goto={goto} complaints={complaints} />;

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 antialiased">
      <NavBar page={page} goto={goto} />
      <main>{content}</main>
      <Footer goto={goto} />
      <FloatingContact />
      <ToastHost toasts={toasts} />
      <div className="h-20 lg:hidden" />
      {/* Sticky mobile report button */}
      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white/95 p-3 backdrop-blur lg:hidden">
        <PrimaryButton full icon={PlusCircle} onClick={() => goto("report")}>Report an Issue</PrimaryButton>
      </div>
    </div>
  );
}
